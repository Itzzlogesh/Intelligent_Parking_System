# Intelligent Parking Space Availability Prediction System for Urban Environments

**Author:** LOGESHWARAN J  
**Reg No:** 927623BAM031  
**Department:** Artificial Intelligence and Machine Learning  
**Course:** AGI1402 / Artificial Intelligence and Advanced Programming  
**Academic Year:** 2026-2027 (IV Year / VII Sem)  

---

## 📌 Project Overview
The **Intelligent Parking Space Availability Prediction System** is a Generative AI-powered smart urban parking assistant designed to reduce traffic congestion and search time. Beyond raw occupancy prediction, the system provides natural-language explanations, short-term availability forecast summaries, and backup lot recommendations.

---

## 🚀 Key Features
- **Natural Language Query Understanding:** Accepts free-text queries like *"Find parking near bus stand at 6:30 PM for 2 hours with covered parking"*.
- **Machine Learning Availability Engine:** Calculates free-space percentage based on current occupancy, peak hours, weekday patterns, and historical trends.
- **Explainable AI (XAI):** Breaks down prediction reasons (e.g., Evening Peak, Low Occupancy, Rising Availability Trend).
- **Short-Term Forecast Summarization:** Synthesizes multi-hour availability expectations into clear driver guidance.
- **Dynamic Fallback / Backup Recommendation:** Recommends secondary parking lots if the primary selection reaches high demand.
- **Web Dashboard & Model Evaluation:** Interactive dashboard featuring real-time predictions, factor breakdowns, and model metrics (MAE, RMSE, Latency).

---

## 📁 Directory Structure
```
Intelligent_Parking_Space_Availability_Prediction_System/
├── app.py                     # Main FastAPI / Web Application
├── parking_model.py           # ML Model Pipeline & Feature Logic
├── ai_assistant.py            # Generative AI & Natural Language Layer
├── requirements.txt           # Project Dependencies
├── README.md                  # Project Documentation
├── data/
│   └── parking_dataset.csv    # Synthetic Urban Parking Dataset
├── static/
│   └── style.css              # Custom Styling for Dashboard
└── templates/
    └── index.html             # Web Application User Interface
```

---

## 🛠️ Installation & Setup

1. **Clone the Repository:**
   ```bash
   git clone https://github.com/LogeshwaranJ/Intelligent-Parking-Space-Availability-Prediction-System.git
   cd Intelligent-Parking-Space-Availability-Prediction-System
   ```

2. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the Application:**
   ```bash
   python app.py
   ```

4. **Access Dashboard:**
   Open your browser and navigate to `http://localhost:8000`
