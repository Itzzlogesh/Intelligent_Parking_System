import pandas as pd
import numpy as np

class ParkingPredictionEngine:
    def __init__(self):
        # Default parking locations database
        self.locations = {
            "Central Parking": {"capacity": 100, "base_occupancy": 0.28, "type": "Covered"},
            "Municipal Parking": {"capacity": 120, "base_occupancy": 0.46, "type": "Open"},
            "Market Parking": {"capacity": 80, "base_occupancy": 0.69, "type": "Covered"}
        }

    def predict_availability(self, location, arrival_time="18:30", duration=2):
        """
        Calculates predicted free space percentage based on temporal and demand factors.
        """
        if location not in self.locations:
            # Fallback to general estimation
            return {"location": location, "availability_pct": 65, "status": "Moderate Availability", "free_spaces": 25}

        lot = self.locations[location]
        occupancy = lot["base_occupancy"]
        
        # Factor adjustments
        hour = int(arrival_time.split(":")[0]) if ":" in arrival_time else 18
        
        # Peak hour penalty
        peak_penalty = 0.15 if 17 <= hour <= 21 else 0.0
        
        predicted_occ = min(0.95, occupancy + peak_penalty)
        free_pct = int((1 - predicted_occ) * 100)
        free_spaces = int((free_pct / 100) * lot["capacity"])

        if free_pct >= 65:
            status = "High Availability"
        elif free_pct >= 40:
            status = "Moderate Availability"
        else:
            status = "Low Availability"

        return {
            "location": location,
            "availability_pct": free_pct,
            "status": status,
            "free_spaces": free_spaces,
            "capacity": lot["capacity"],
            "occupancy_rate": predicted_occ,
            "hour": hour
        }

    def get_all_predictions(self, arrival_time="18:30"):
        results = []
        for loc in self.locations:
            results.append(self.predict_availability(loc, arrival_time))
        return sorted(results, key=lambda x: x["availability_pct"], reverse=True)
