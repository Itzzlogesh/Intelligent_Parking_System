from parking_model import ParkingPredictionEngine

class GenerativeParkingAssistant:
    def __init__(self):
        self.engine = ParkingPredictionEngine()

    def parse_query(self, query_text):
        """Extracts location and arrival preferences from free-text queries."""
        query_text_lower = query_text.lower()
        
        location = "Central Parking"
        if "bus stand" in query_text_lower or "central" in query_text_lower:
            location = "Central Parking"
        elif "municipal" in query_text_lower:
            location = "Municipal Parking"
        elif "market" in query_text_lower:
            location = "Market Parking"

        return {
            "location": location,
            "time": "06:30 PM",
            "duration": "2 Hours",
            "preference": "Covered Parking"
        }

    def generate_explanation(self, prediction):
        """Generates factor-based explainability response."""
        factors = []
        
        # Current occupancy factor
        if prediction["occupancy_rate"] < 0.40:
            factors.append({"factor": "Current occupancy", "value": "Low", "impact": "Positive"})
        else:
            factors.append({"factor": "Current occupancy", "value": "Moderate to High", "impact": "Neutral"})

        # Time of day factor
        if 17 <= prediction["hour"] <= 21:
            factors.append({"factor": "Time of day", "value": "Evening peak", "impact": "Negative"})
        else:
            factors.append({"factor": "Time of day", "value": "Off-peak", "impact": "Positive"})

        # Weekday pattern & trend
        factors.append({"factor": "Weekday pattern", "value": "Moderate demand", "impact": "Neutral"})
        factors.append({"factor": "Recent trend", "value": "Availability rising", "impact": "Positive"})

        return factors

    def generate_forecast_summary(self, primary_pred, all_preds):
        """Generates friendly short-term summary and backup lot guidance."""
        primary_name = primary_pred["location"]
        primary_pct = primary_pred["availability_pct"]
        
        summary = (
            f"At 6:30 PM, {primary_name} is expected to have good availability with around "
            f"{primary_pct}% of spaces free. Demand is likely to increase during the evening peak, "
            f"so availability may fall to about 60% within the next two hours."
        )

        # Find alternative lot
        backup_lot = [p for p in all_preds if p["location"] != primary_name][0]
        backup_name = backup_lot["location"]
        
        recommendation = f"Proceed to {primary_name}; keep {backup_name} as backup."

        return {
            "summary_text": summary,
            "recommended_action": recommendation,
            "backup_lot": backup_name
        }
