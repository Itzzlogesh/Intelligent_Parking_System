import uvicorn
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

from ai_assistant import GenerativeParkingAssistant
from parking_model import ParkingPredictionEngine

app = FastAPI(
    title="ParkPredict AI Assistant",
    description="Intelligent parking space availability prediction system for urban environments",
    version="1.0.0"
)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

assistant = GenerativeParkingAssistant()
engine = ParkingPredictionEngine()

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    all_preds = engine.get_all_predictions()
    primary = all_preds[0]
    explanation = assistant.generate_explanation(primary)
    summary = assistant.generate_forecast_summary(primary, all_preds)
    
    return templates.TemplateResponse("index.html", {
        "request": request,
        "predictions": all_preds,
        "primary": primary,
        "explanation": explanation,
        "summary": summary,
        "query_text": "Find parking near Karur Bus Stand at 6:30 PM for 2 hours with covered parking"
    })

@app.post("/analyze", response_class=HTMLResponse)
async def analyze(request: Request, query: str = Form(...)):
    parsed = assistant.parse_query(query)
    primary = engine.predict_availability(parsed["location"])
    all_preds = engine.get_all_predictions()
    
    explanation = assistant.generate_explanation(primary)
    summary = assistant.generate_forecast_summary(primary, all_preds)

    return templates.TemplateResponse("index.html", {
        "request": request,
        "predictions": all_preds,
        "primary": primary,
        "explanation": explanation,
        "summary": summary,
        "query_text": query
    })

@app.get("/health")
def health():
    return {"status": "active", "system": "ParkPredict AI Engine"}

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
